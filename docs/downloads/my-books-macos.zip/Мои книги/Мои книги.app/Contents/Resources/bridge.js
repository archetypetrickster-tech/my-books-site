(() => {
  'use strict';
  if (location.hostname !== 'books.yandex.ru' || window.__books) return;
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const media = new Set();
  let playbackAllowed = false;
  const originalPlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = function () {
    media.add(this);
    if (!playbackAllowed) return Promise.reject(new DOMException('Нажмите воспроизведение', 'NotAllowedError'));
    const savedRate = Number(localStorage.getItem('my-books-rate'));
    if (savedRate >= .5 && savedRate <= 3) this.playbackRate = savedRate;
    return originalPlay.call(this);
  };
  const state = { library: '', mode: 'home', selected: 0, hasText: false, hasAudio: false, last: '' };
  let host, shadow, panel, content, searchInput, timer, lastRoute = '', lastSignature = '', compact = false, meta = null;
  let localHome = false, homeTab = 0, settingsOpen = false, chaptersOpen = false, filter = 'all', libraryFilter = 'all';
  let lastPost = '', routeGeneration = 0, errorTimer, requestedMore = false;
  let homeRestoreScroll = null;
  const metaCache = new Map();
  const coverObservers = new Set();
  let libraryQuery = sessionStorage.getItem('my-books-library-query') || '';
  let loadingLibrary = false, libraryExpanded = false, libraryData = null, libraryError = '';
  let recommendations = null, loadingRecommendations = false, recommendationError = '';
  const libraryCache = new Map(), bookNodes = new Map();
  let libraryWarmup = null, libraryRequests = 0, homeView = null;
  let readerCover = null, readerCoverFile = '', readerCoverFrame = 0, readerCoverReturningUntil = 0;
  const searchable = value => normal(value).toLocaleLowerCase('ru').replace(/ё/g,'е');
  const normal = s => (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const text = (s, root = document) => normal($(s, root)?.textContent);
  const icon = name => (window.__bookIcons || {})[name] || '';
  const safeURL = raw => {
    if (!raw) return ''; try { const u = new URL(raw, location.origin); return u.origin === location.origin ? u.href : ''; } catch { return ''; }
  };
  const coverURL = raw => {
    if (!raw) return ''; try { const u = new URL(raw, location.origin); return u.protocol === 'https:' && /(^|\.)(bookmate\.ru|yandex\.net|yandex\.ru)$/.test(u.hostname) ? u.href : ''; } catch { return ''; }
  };
  function el(tag, cls, value) {
    const n = document.createElement(tag); if (cls) n.className = cls; if (value !== undefined) n.textContent = value; return n;
  }
  function button(label, fn, cls = '', svg = '') {
    const b = el('button', cls); b.type = 'button'; b.title = label; b.setAttribute('aria-label', label);
    if (svg) { const span = el('span', 'icon'); span.innerHTML = svg; b.append(span); }
    else b.textContent = label;
    b.addEventListener('click', fn); return b;
  }
  function post() {
    const message = JSON.stringify(state);
    if (message !== lastPost) { lastPost = message; window.webkit?.messageHandlers?.books?.postMessage({...state}); }
  }
  function navigate(raw) {
    const url = safeURL(raw); if (!url) return;
    for (const a of media) a.pause();
    playbackAllowed = false;
    if(window.webkit?.messageHandlers?.books){window.webkit.messageHandlers.books.postMessage({action:'navigate',url});return;}
    location.assign(url);
  }
  function originalClick(selector) { const b = $(selector); if (b) { b.click(); schedule(); return true; } return false; }
  function playerButton(name) { return $('[data-test-id="AUDIO_PLAYER_' + name + '"]')?.closest('button'); }
  function currentMedia() { return [...media].find(m => !m.paused) || [...media].reverse().find(m => Number.isFinite(m.duration)); }
  function pause() { for (const m of media) m.pause(); const b = $('button[aria-label="Пауза"]'); if (b && !media.size) b.click(); }
  function togglePlayback() {
    if ($('[data-test-id="AUDIO_PLAYER_PAUSE"]')) { const b = $('[data-test-id="AUDIO_PLAYER_PAUSE"]').closest('button'); b?.click(); }
    else {
      playbackAllowed = true;
      const b = playerButton('PLAY') || $$('button').find(b => normal(b.textContent) === 'Слушать');
      if (b) b.click(); else if (currentMedia()) currentMedia().play().catch(() => showError('Не удалось включить аудио. Обнови книгу и попробуй ещё раз.'));
    }
    schedule();
  }
  function seek(seconds) {
    const m = currentMedia();
    if (m && Number.isFinite(m.duration)) m.currentTime = Math.max(0, Math.min(m.duration, seconds));
    else { const range = $('input[aria-label="Позиция воспроизведения"]'); if (range) { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(range, seconds); range.dispatchEvent(new Event('input', {bubbles:true})); range.dispatchEvent(new Event('change', {bubbles:true})); } }
  }
  const time = sec => {
    sec = Math.max(0, Math.floor(Number(sec) || 0));
    const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = String(sec % 60).padStart(2, '0');
    return h ? h + ':' + String(m).padStart(2, '0') + ':' + s : m + ':' + s;
  };

  async function metadata(kind, id) {
    const key = kind + '/' + id;
    if (metaCache.has(key)) return metaCache.get(key);
    const promise = (async () => {
      const response = await fetch('/node-api/p/api/v5/' + key, {credentials:'same-origin'});
      if (!response.ok) throw new Error('Книга недоступна');
      const data = await response.json();
      const item = data.book || data.audiobook;
      if (!item) throw new Error('Книга недоступна');
      const textId = kind === 'books' ? id : item.linked_book_uuids?.[0];
      const audioId = kind === 'audiobooks' ? id : item.linked_audiobook_uuids?.[0];
      return {
        title:item.title || '', author:typeof item.authors === 'string' ? item.authors : (item.authors || []).map(a=>a.name).join(', '),
        cover:coverURL(item.cover?.large || item.cover?.small || ''),
        reader:textId ? location.origin + '/reader/' + encodeURIComponent(textId) + '?resource=book' : '',
        audio:audioId ? location.origin + '/audiobooks/' + encodeURIComponent(audioId) : '', kind,id
      };
    })();
    metaCache.set(key, promise);
    try { return await promise; } catch (e) { metaCache.delete(key); throw e; }
  }
  function mount() {
    if (host?.isConnected) return;
    host = el('div'); host.id = 'my-books-widget';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483000;display:block;isolation:isolate';
    shadow = host.attachShadow({mode:'open'});
    const style = el('style'); style.textContent = `
      :host{color:#f4f4f6;font:14px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color-scheme:dark}
      *{box-sizing:border-box}button,input,select{font:inherit}button{border:0;color:inherit;cursor:pointer;background:transparent}button:disabled{opacity:.3;cursor:default}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid #ffdf36;outline-offset:3px}
      .panel{height:100%;overflow-x:hidden;overflow-y:scroll;overscroll-behavior:contain;padding:0 16px 16px;background:transparent}
      .panel::-webkit-scrollbar{width:7px;height:7px}.panel::-webkit-scrollbar-track{background:transparent;margin:4px 0}.panel::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12);border:2px solid transparent;border-left-width:3px;border-radius:7px;background-clip:padding-box}.panel::-webkit-scrollbar-thumb:hover{background-color:rgba(255,255,255,.22)}.panel::-webkit-scrollbar-corner{background:transparent}
      .search{display:flex;align-items:center;gap:8px;background:#ffffff08;border:1px solid #ffffff0d;border-radius:11px;padding:0 12px;height:40px;margin:16px 0 16px}.search input{width:100%;border:0;outline:0;background:none;color:#fff;font-size:13px}.search svg{width:16px;height:16px;fill:#aaa}.search button{font-size:20px;color:#999;padding:0}
      .eyebrow{font-size:10px;letter-spacing:1.4px;color:#92929e;text-transform:uppercase;margin:20px 0 10px}.heading{font-size:22px;letter-spacing:-.5px;line-height:1.2;font-weight:700;margin:6px 0 5px}.sub{font-size:12px;line-height:1.5;color:#92929e;margin:0 0 16px}.chips[hidden]{display:none}.chips.library-status{position:relative;flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;scrollbar-width:none}.library-status::-webkit-scrollbar{display:none}.library-status .chip{flex:0 0 auto;white-space:nowrap;padding-inline:7px}.chips{display:flex;gap:4px;flex-wrap:wrap;margin:0 0 12px}.chip{padding:6px 9px;border-radius:8px;font-size:11px;color:#a4a4af;background:#ffffff04;transition:background .16s,color .16s}.chip:hover{background:#ffffff10;color:white}.chip.active{color:#ffdf36;background:#ffffff0e}
      .list{display:flex;flex-direction:column;gap:4px}.book{width:100%;display:grid;grid-template-columns:46px minmax(0,1fr) 22px;gap:12px;padding:9px 4px;border-radius:9px;text-align:left;align-items:center;min-height:82px;transition:background .16s}.book:hover{background:#ffffff09}.book .cover{height:66px;width:46px;border-radius:4px;position:relative;display:grid;place-items:center;overflow:hidden;background:#292929;box-shadow:0 3px 10px #0003}.book .cover>.icon{color:#ff0;width:20px;height:20px}.book .cover>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0}.book.audio .cover{height:46px}.cover-placeholder{display:grid;place-items:center;color:#ffdf36;font-size:18px}.name{font-size:14px;font-weight:600;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.author{font-size:12px;color:#92929e;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.format{font-size:10px;color:#b6b6c0;margin-top:5px;display:flex;gap:6px;align-items:center}.format .icon{width:12px;height:12px}.chevron{color:#767680;font-size:20px;font-weight:300}.progress-line{height:2px;width:100%;margin-top:8px;background:#ffffff10;border-radius:2px;overflow:hidden}.progress-line i{height:100%;display:block;background:#ffdf36}
      .empty{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;min-height:260px;padding:28px 12px}.empty .mark{font-size:42px;color:#ffdf36;margin-bottom:20px}.empty p{color:#92929e;line-height:1.6;font-size:13px;max-width:260px}.primary{background:#ffdf36;color:#19191e;border-radius:24px;padding:12px 22px;font-weight:600;font-size:13px;transition:background .15s}.primary:hover{background:#ffe967}.secondary{padding:9px 12px;border-radius:9px;background:#ffffff0b;font-size:12px;color:#bbb}.loading{width:20px;height:20px;border-radius:50%;border:2px solid #ffffff12;border-top-color:#ffdf36;animation:spin .8s linear infinite;margin:24px auto}@keyframes spin{to{transform:rotate(360deg)}}
      .audio-view{position:relative;padding-top:0}.ambient{position:absolute;inset:0 0 0;opacity:.19;filter:blur(55px);background-size:cover;pointer-events:none}.audio-content{position:relative}.hero-cover{width:100%;height:min(calc(100vh - 270px),calc(100vw - 32px),320px);min-height:110px;object-fit:contain;border-radius:6px;display:block;margin:0 auto 15px;filter:drop-shadow(0 12px 20px #0005)}.audio-title{font-size:20px;line-height:1.3;font-weight:700;letter-spacing:-.3px;margin:0 0 5px}.audio-author{font-size:13px;color:#aaaab4}.audio-meta{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:8px 0 12px;min-height:30px}.chapter{font-size:12px;color:#b2b2be;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.tools{display:flex;gap:2px;align-items:center}.tool{height:32px;min-width:32px;padding:0 7px;border-radius:9px;color:#aaaab5;font-size:11px}.tool:hover{background:#ffffff10;color:#fff}.icon{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;flex-shrink:0}.icon svg{width:100%;height:100%}.icon svg [fill]:not([fill="none"]){fill:currentColor}.icon svg path:not([fill]){fill:currentColor}.timeline{display:block;width:100%;height:14px;accent-color:#ffdf36;margin:0;cursor:pointer}.times{display:flex;justify-content:space-between;font:10px -apple-system,sans-serif;font-variant-numeric:tabular-nums;color:#92929e;margin-top:3px}.controls{display:flex;align-items:center;justify-content:space-evenly;margin:14px 14px 2px}.skip{height:40px;width:40px;position:relative;color:#b6b6c0}.skip:hover{color:#fff}.skip .icon{width:26px;height:26px}.skip small{position:absolute;left:0;right:0;bottom:6px;font-size:9px}.play{display:flex;align-items:center;justify-content:center;background:#ffdf36;color:#17171d;width:56px;height:56px;border-radius:50%;transition:transform .12s,background .15s}.play:hover{background:#ffe967}.play:active{transform:scale(.94)}.play .icon{width:26px;height:26px}.audio-note{font-size:11px;line-height:1.5;text-align:center;color:#8f8f9d;margin:14px 0 0}.compact .hero-cover{width:60px;height:70px;min-height:0;float:left;margin:0 12px 8px 0}.compact .audio-title{font-size:16px;padding-top:6px}.compact .audio-meta{margin:0 0 4px}.compact .controls{margin:7px 14px 0}.compact .play{width:46px;height:46px}.compact .audio-note{display:none}.compact .timeline{clear:both}.compact .panel{padding-bottom:10px}
      .chapter-header{position:sticky;top:0;background:#1a1a25;z-index:2;padding:0 0 12px}.chapter-row{scroll-margin-top:100px;display:flex;justify-content:space-between;align-items:center;padding:13px 9px;text-align:left;border-radius:8px;font-size:13px}.chapter-row:hover{background:#ffffff09}.chapter-row.active{color:#ffdf36;background:#ffffff07}.chapter-row .sub{margin:0;font-size:11px}.settings{display:flex;flex-direction:column;gap:16px;padding:10px 0}.settings-row{display:flex;align-items:center;justify-content:space-between;gap:10px;color:#b9b9c3;font-size:13px}select{color:white;background:#ffffff0c;border:1px solid #ffffff10;border-radius:8px;padding:7px}.error{padding:15px;background:#ffffff07;color:#bbb;font-size:12px;line-height:1.5;border-radius:10px}.footer{padding:20px 0 8px;text-align:center;font-size:10px;color:#686874}.footer a{color:#92929e}.reader-tools{display:flex;gap:8px}.settings h2{font-size:20px;margin:0}
      @media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
    `;
    shadow.append(style); panel = el('main', 'panel'); shadow.append(panel); content = el('div'); panel.append(content); document.body.append(host);
    panel.addEventListener('scroll', () => {
      if (state.mode !== 'home' || localHome) return;
      const ratio = panel.scrollTop / Math.max(1, panel.scrollHeight - panel.clientHeight);
      window.scrollTo(0, ratio * Math.max(0, document.documentElement.scrollHeight - innerHeight));
      if (ratio > .85 && !requestedMore) {
        const more = $$('button').find(b => /показать (ещё|еще)|загрузить (ещё|еще)/i.test(normal(b.textContent)));
        if (more) { requestedMore = true; more.click(); setTimeout(() => {requestedMore = false; schedule();}, 900); }
      }
    }, {passive:true});
  }
  function shell(show = true) {
    mount(); host.style.display = show ? 'block' : 'none';
    document.documentElement.classList.toggle('my-books-shell', show);
    document.documentElement.toggleAttribute('data-my-books-shell',show);
  }
  function installPageStyle() {
    if ($('#my-books-style')) return;
    const s = el('style'); s.id = 'my-books-style';
    s.textContent = `#my-books-reader-cover[hidden]{display:none!important}html[data-my-books-shell] body>:not(#my-books-widget){opacity:0!important;pointer-events:none!important}html[data-my-books-shell] body *{visibility:hidden!important;pointer-events:none!important}html[data-my-books-shell] #my-books-widget{visibility:visible!important;pointer-events:auto!important}html[data-my-books-shell]{background:transparent!important;overflow:hidden!important;overscroll-behavior:none!important;max-width:100vw!important}html[data-my-books-shell] body{background:transparent!important;overflow:hidden!important;width:100%!important;height:100vh!important;max-height:100vh!important;max-width:100vw!important;margin:0!important}html[data-my-books-shell]::-webkit-scrollbar,html[data-my-books-shell] body::-webkit-scrollbar{display:none!important}html.my-books-reader [data-test-id="HEADER"]{display:none!important}html.my-books-reader [data-test-id="READER_PAGE"]{--reader-header-height:0px}html.my-books-reader [data-reader-page-direction]{display:none!important}html.my-books-reader{min-width:0!important;max-width:100vw!important;overflow:hidden!important;overscroll-behavior:none!important}html.my-books-reader body{overflow:hidden!important;overscroll-behavior:none!important}html.my-books-reader::-webkit-scrollbar,html.my-books-reader body::-webkit-scrollbar{display:none!important}html.my-books-reader[style*="color-scheme: dark"]{--reader-background:#1a1a25!important;--reader-text:#dddde7!important;background-color:#1a1a25!important}html.my-books-reader body{background:transparent!important}html.my-books-reader[style*="color-scheme: dark"] [data-reader-theme]{--reader-background:#1a1a25!important;background:#1a1a25!important}html.my-books-reader [data-test-id="READER_FOOTER"]{display:none!important}html.my-books-reader [class*="Footer-module"]{visibility:hidden!important}html.my-books-quick-settings [role="dialog"]{visibility:hidden!important}html.my-books-reader [data-test-id="READER_FOOTER"]{padding-left:16px!important;padding-right:16px!important}html.my-books-chapters [role="dialog"],html.my-books-chapters [data-base-ui-portal]{display:none!important}`;
    (document.head||document.documentElement).append(s);
  }
  function prepareReaderTurn(direction){
    const position=$('r-root')?.readerController?.readPosition;
    readerCoverReturningUntil=0;
    if(direction==='back'&&position?.fileIndex===1&&position.progress===0&&readerCover){readerCover.hidden=false;readerCoverReturningUntil=performance.now()+1500;}
    cancelAnimationFrame(readerCoverFrame);
    const until=performance.now()+1500;
    const tick=()=>{updateReaderCover();if(performance.now()<until)readerCoverFrame=requestAnimationFrame(tick);};
    readerCoverFrame=requestAnimationFrame(tick);
  }
  function updateReaderCover(){
    const controller=$('r-root')?.readerController,position=controller?.readPosition;
    const first=controller?.orderedFileIds?.[0];
    if(!controller||!position||!first){if(readerCover)readerCover.hidden=true;return;}
    const chapter=$$('.embed-element r-chapter-horizontal').find(node=>node.dataset.itemId===first);
    const images=chapter?$$('img.reader-image',chapter):[];
    const image=images.length===1?images[0]:null;
    const src=chapter?.dataset.itemId===first&&!normal(chapter.textContent)&&image?.naturalWidth>0?safeURL(image.currentSrc||image.src):'';
    if(src&&(!readerCover?.isConnected||readerCover.dataset.src!==src)){
      readerCover?.remove();readerCover=el('div');readerCover.id='my-books-reader-cover';readerCover.dataset.src=src;readerCoverFile=first;
      readerCover.setAttribute('aria-hidden','true');readerCover.hidden=true;readerCover.style.cssText='position:fixed;inset:0;z-index:20;overflow:hidden;pointer-events:none;background:var(--reader-background,#1a1a25)';
      const art=el('img');art.alt='';art.src=src;art.style.cssText='display:block;width:100%;height:100%;object-fit:cover;object-position:center';readerCover.append(art);document.body.append(readerCover);
    }
    if(!readerCover)return;
    if(state.mode!=='reader'||readerCoverFile!==first||$('[role="dialog"]')){readerCover.hidden=true;return;}
    if(position?.fileIndex===0&&position.progress===0){readerCoverReturningUntil=0;readerCover.hidden=false;return;}
    if(performance.now()<readerCoverReturningUntil){readerCover.hidden=false;return;}
    // Keep the decoded cover in front until the new chapter has finished painting.
    const current=$$('.embed-element r-chapter-horizontal').find(node=>node.dataset.itemId===position?.fileId);
    const source=image?.getBoundingClientRect();
    const sourceVisible=source&&source.right>0&&source.left<innerWidth&&source.bottom>0&&source.top<innerHeight;
    if(!controller.isRendering&&current&&current.dataset.itemId!==readerCoverFile&&!sourceVisible)readerCover.hidden=true;
  }
  function empty(title, subtitle, action, parent=content) {
    const box = el('div','empty'); const mark = el('span','mark icon'); mark.innerHTML=icon('brand'); mark.style.cssText='width:42px;height:42px'; box.append(mark,el('h2','heading',title),el('p','',subtitle));
    if (action) box.append(button(action[0],action[1],'primary')); parent.append(box);
  }
  function showError(message,parent=content) { const box = el('div','error',message); parent.prepend(box); }
  function accountLink() {
    return $$('a[href]').find(a => /\/@[^/]+\/books\//.test(a.getAttribute('href') || '') && /Мои книги/.test(a.textContent));
  }
  function findLibrary() {
    const a = accountLink(); if (a) state.library = safeURL(a.href);
    if (/^\/@[^/]+\/(books|audiobooks)\//.test(location.pathname)) state.library = location.origin + location.pathname.replace(/\/(books|audiobooks)\/.*$/, '/books/all');
  }
  function login() {
    window.webkit?.messageHandlers?.books?.postMessage({action:'login'});
  }
  function searchBox(isLibrary = false) {
    const form = el('form','search');
    const mark = el('span'); mark.innerHTML = '<svg viewBox="0 0 24 24"><path d="M10.5 3a7.5 7.5 0 1 0 4.6 13.4l4.2 4.2a.9.9 0 0 0 1.3-1.3l-4.2-4.2A7.5 7.5 0 0 0 10.5 3m0 1.8a5.7 5.7 0 1 1 0 11.4 5.7 5.7 0 0 1 0-11.4"/></svg>';
    searchInput = el('input'); searchInput.type = 'search'; searchInput.placeholder = isLibrary ? 'Найти в библиотеке' : 'Книга или автор'; searchInput.setAttribute('aria-label',isLibrary ? 'Поиск по моей библиотеке' : 'Поиск книг');
    const parts = location.pathname.split('/'); searchInput.value = isLibrary ? libraryQuery : parts[1] === 'search' && parts[3] ? decodeURIComponent(parts.slice(3).join('/')) : '';
    let debounce;
    const submit = submitted => {
      const q = (typeof submitted==='string'?submitted:searchInput.value).trim();
      if(isLibrary){libraryQuery=q;sessionStorage.setItem('my-books-library-query',q);if(q&&libraryFilter!=='all')selectLibrary('all',filter);lastSignature='';renderHome();return;}
      sessionStorage.setItem('my-books-search-focus','1');
      navigate(q ? '/search/all/' + encodeURIComponent(q) : '/search');
    };
    searchInput.addEventListener('input',event=>{const query=event.currentTarget.value;clearTimeout(debounce);debounce=setTimeout(()=>submit(query),isLibrary?120:400);});
    form.addEventListener('submit',e=>{e.preventDefault();clearTimeout(debounce);submit();});
    form.append(mark,searchInput); panel.prepend(form);
    if(!isLibrary&&sessionStorage.getItem('my-books-search-focus')==='1'){
      sessionStorage.removeItem('my-books-search-focus');
      requestAnimationFrame(()=>{searchInput?.focus();const end=searchInput?.value.length||0;searchInput?.setSelectionRange(end,end);});
    }
  }
  function collectCards() {
    if(state.mode==='home'&&homeTab===1)return libraryData||[];
    if(state.mode==='home'&&homeTab===0&&location.pathname==='/search')return recommendations||[];
    const found = new Map();
    const candidates = $$('[data-test-id="SNIPPET"], .book, .audiobook');
    // Legacy library pages use .book; the new search uses SNIPPET.
    for (const node of candidates) {
      const link = $('a[href^="/books/"],a[href^="/audiobooks/"]',node);
      if (!link) continue;
      const href = safeURL(link.href);if(!href)continue;const path = new URL(href).pathname;
      if (!/^\/(books|audiobooks)\/[^/]+$/.test(path)) continue;
      const audio = path.startsWith('/audiobooks/');
      const title = normal(link.title || $('[data-test-id="SNIPPET_TITLE"],.book__title,.audiobook__title',node)?.textContent || link.textContent);
      const authorNode = $('[data-test-id="SNIPPET_AUTHORS"],.book__authors,.book__author,.audiobook__authors,.audiobook__author',node);
      const authorLinks = authorNode ? $$('a',authorNode) : [];
      const author = authorLinks.length ? authorLinks.map(a=>normal(a.textContent)).join(', ') : normal(authorNode?.textContent);
      const img = $('img',node); const cover = coverURL(img?.currentSrc || img?.src || '');
      const progress = normal(node.textContent).match(/(\d{1,3})%/);
      if (found.has(href) && !author) continue;
      if (title) found.set(href,{href,title:title.replace(/18\+$/,'').trim(),author,cover,audio,progress:progress?Number(progress[1]):0,node});
    }
    return [...found.values()];
  }
  function setCoverImage(wrapper,url){
    const image=el('img');image.alt='';image.loading='lazy';image.addEventListener('load',()=>image.style.opacity='1');image.src=url;wrapper.append(image);if(image.complete&&image.naturalWidth)image.style.opacity='1';
  }
  function renderList(cards, isLibrary, parent=content) {
    const list = el('div','list');
    for (const card of cards.filter(c=>(filter==='all'||(filter==='audio'?c.audio:!c.audio))&&(!isLibrary||!libraryQuery||searchable(c.title+' '+c.author).includes(searchable(libraryQuery))))) {
      const cached=bookNodes.get(card.href);if(cached){list.append(cached);continue;}
      const b = button(card.title,()=>navigate(card.audio?card.href:card.href.replace('/books/','/reader/')+'?resource=book'),'book'+(card.audio?' audio':''));
      b.textContent='';
      const cover=el('span','cover');const logo=el('span','icon');logo.innerHTML=icon('brand');cover.append(logo);if(card.cover)setCoverImage(cover,card.cover);
      b.append(cover); const info=el('div'); info.append(el('div','name',card.title),el('div','author',card.author));
      const detail=el('div','format'); detail.append(el('span','',card.audio?'Аудиокнига':'Текст'),el('span','',card.progress?card.progress+'%':''));info.append(detail);
      if(card.progress){const track=el('div','progress-line');const fill=el('i');fill.style.width=Math.min(100,card.progress)+'%';track.append(fill);info.append(track);}
      b.append(info,el('span','chevron','›'));list.append(b);bookNodes.set(card.href,b);
      if (!card.cover && isLibrary) {
        const [kind,id]=new URL(card.href).pathname.slice(1).split('/');
        const observer = new IntersectionObserver(entries=>{
          if (!entries.some(e=>e.isIntersecting)) return; observer.disconnect();coverObservers.delete(observer);
          metadata(kind,id).then(m=>{if(m.cover&&cover.isConnected)setCoverImage(cover,m.cover);}).catch(()=>{});
        },{root:panel,rootMargin:'120px'});coverObservers.add(observer);observer.observe(b);
      }
    }
    parent.append(list);
    if(isLibrary&&libraryQuery&&!list.children.length&&!loadingLibrary)empty('Ничего не найдено','Попробуй другое название или имя автора.',null,parent);
  }
  function serviceCard(item) {
    const book=item?.book;if(!book?.uuid)return null;
    const audio=item.__typename==='AudioBook',id=book.initUuid||book.uuid;
    return {href:location.origin+'/'+(audio?'audiobooks':'books')+'/'+encodeURIComponent(id),title:book.name||'',author:(book.authors||[]).map(a=>a.name).filter(Boolean).join(', '),cover:coverURL(book.cover?.url||''),audio,progress:Number(item.progress?.progress)||0};
  }
  async function loadRecommendations(){
    if(loadingRecommendations||recommendations!==null||recommendationError)return;
    const request=window.__booksRecommendationRequest;if(!request?.query)return;
    loadingRecommendations=true;schedule();
    try{
      const response=await fetch('/node-api/p-graphql/',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
      if(!response.ok)throw new Error();const json=await response.json();
      if(json.errors)throw new Error();
      const section=json.data?.showcase?.items?.page?.find(item=>normal(item.name)==='Вам может понравиться');
      if(!section?.items?.page)throw new Error();
      recommendations=section.items.page.map(serviceCard).filter(Boolean);
    }catch{recommendationError='Не удалось загрузить рекомендации. Можно повторить или найти книгу через поиск.';}
    finally{loadingRecommendations=false;lastSignature='';schedule();}
  }
  function bookCount(count){const n=count%100;return count+' '+(n>=11&&n<=14?'книг':count%10===1?'книга':count%10>=2&&count%10<=4?'книги':'книг');}
  function libraryKey(status=libraryFilter,format=filter){return (format==='audio'?'audio':'text')+':'+status;}
  function libraryEntry(status=libraryFilter,format=filter){
    const key=libraryKey(status,format);
    if(!libraryCache.has(key))libraryCache.set(key,{cards:[],complete:false,error:'',promise:null});
    return libraryCache.get(key);
  }
  function syncLibrary(){
    const entry=libraryEntry();libraryData=entry.cards;libraryExpanded=entry.complete;libraryError=entry.error;loadingLibrary=!!entry.promise;
  }
  async function loadLibraryEntry(status,format){
    const entry=libraryEntry(status,format);
    if(entry.promise)return entry.promise;if(entry.complete)return;
    const login=state.library.match(/\/@([^/]+)/)?.[1];
    if(!login||!window.__booksLibraryRequest?.query)return;
    const key=libraryKey(status,format),cards=new Map();
    entry.promise=(async()=>{
      try{
        for(const contentFilter of format==='audio'?['AUDIOBOOK']:['TEXTBOOK','COMICBOOK']){
          let cursor='';const seen=new Set();
          do{
            const request={...window.__booksLibraryRequest,variables:{userLogin:login,params:{cursor,step:20,contentFilter,state:({all:'ALL',recent:'OPENED',not_finished:'ADDED',finished:'FINISHED'})[status]||'ALL'}}};
            libraryRequests++;
            const response=await fetch('/graphql-proxy',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
            if(!response.ok)throw new Error();const json=await response.json(),page=json.data?.user?.library?.books;
            if(json.errors||!page)throw new Error();
            for(const item of page.page||[]){const card=serviceCard(item);if(card)cards.set(card.href,card);}
            entry.cards=[...cards.values()];
            if(key===libraryKey()){syncLibrary();schedule();}
            cursor=page.cursor||'';if(cursor&&seen.has(cursor))throw new Error();seen.add(cursor);
          }while(cursor);
        }
      }catch{entry.error='Не удалось проверить всю библиотеку. Можно повторить загрузку.';}
      finally{entry.complete=true;entry.promise=null;if(key===libraryKey()){syncLibrary();lastSignature='';schedule();}}
    })();
    if(key===libraryKey()){syncLibrary();schedule();}
    return entry.promise;
  }
  function warmLibrary(){
    if(libraryWarmup)return;
    const pending=[];
    for(const format of ['text','audio'])for(const status of ['all','recent','not_finished','finished'])if(libraryKey(status,format)!==libraryKey())pending.push([status,format]);
    const worker=async()=>{while(pending.length){const [status,format]=pending.shift();await loadLibraryEntry(status,format);}};
    libraryWarmup=Promise.all([worker(),worker()]);
  }
  async function expandLibrary(force=false){
    if(!state.library||(!libraryQuery&&!force))return;
    const active=loadLibraryEntry(libraryFilter,filter);warmLibrary();await active;syncLibrary();
  }
  function selectLibrary(status,format){
    libraryFilter=status;filter=format;syncLibrary();lastSignature='';homeRestoreScroll=0;renderHome();
    if(!libraryExpanded)expandLibrary(true);
  }
  function renderHome() {
    shell();document.documentElement.classList.remove('my-books-reader');
    const isLibrary=homeTab===1,recommending=!isLibrary&&location.pathname==='/search';
    if(isLibrary)syncLibrary();
    const cards=collectCards();
    const key=JSON.stringify([location.pathname,isLibrary,filter,libraryFilter,libraryQuery,loadingLibrary,libraryExpanded,libraryError,loadingRecommendations,recommendationError,cards.map(c=>[c.href,c.cover,c.progress]),state.library,settingsOpen]);
    if(key===lastSignature)return;lastSignature=key;
    clearTimeout(errorTimer);
    const scroll=panel.scrollTop;
    if(!homeView?.root.isConnected){
      const root=el('div','home-view'),heading=el('h1','heading'),subtitle=el('p','sub'),statuses=el('div','chips library-status'),formats=el('div','chips'),results=el('div','home-results');
      const addChips=(row,items,select)=>{for(const [key,label]of items){const b=button(label,()=>select(key),'chip');b.dataset.key=key;row.append(b);}};
      if(isLibrary)addChips(statuses,[['all','Все'],['recent','Открытые'],['not_finished','Добавленные'],['finished','Законченные']],key=>{libraryQuery='';sessionStorage.setItem('my-books-library-query','');selectLibrary(key,filter);});
      addChips(formats,isLibrary?[['text','Текст'],['audio','Аудио']]:[['all','Все'],['text','Текст'],['audio','Аудио']],key=>{if(isLibrary)selectLibrary(libraryFilter,key);else{filter=key;lastSignature='';renderHome();}});
      root.append(heading,subtitle,statuses,formats,results);content.replaceChildren(root);
      panel.querySelector('.search')?.remove();searchBox(isLibrary);
      homeView={root,heading,subtitle,statuses,formats,results};
    }
    const {heading,subtitle,statuses,formats,results}=homeView;
    const formatCards=cards.filter(c=>filter==='all'||(filter==='audio'?c.audio:!c.audio));
    const foundCards=libraryQuery?formatCards.filter(c=>searchable(c.title+' '+c.author).includes(searchable(libraryQuery))):formatCards;
    const caption=isLibrary?(libraryError?'Неполный список: '+bookCount(formatCards.length):!libraryExpanded?'Загружаем библиотеку…':libraryQuery?'Найдено '+foundCards.length+' из '+formatCards.length:bookCount(formatCards.length)):recommending?'Рекомендации Яндекс Книг':'Книги и аудиокниги Яндекса';
    const title=isLibrary?'Моя библиотека':recommending?'Вам может понравиться':'Результаты поиска';
    if(heading.textContent!==title)heading.textContent=title;if(subtitle.textContent!==caption)subtitle.textContent=caption;
    statuses.hidden=!isLibrary||!state.library;formats.hidden=recommending;
    for(const b of statuses.children)b.classList.toggle('active',b.dataset.key===libraryFilter);
    for(const b of formats.children)b.classList.toggle('active',b.dataset.key===filter);
    results.replaceChildren();
    if(isLibrary&&!state.library)empty('Твои книги — здесь','Войди в Яндекс, чтобы открыть свою библиотеку.',['Войти в Яндекс',login],results);
    else if(cards.length)renderList(cards,isLibrary,results);
    else if(recommending){
      if(recommendationError){showError(recommendationError,results);results.append(button('Повторить',()=>{recommendationError='';loadRecommendations();},'secondary'));}
      else if(recommendations?.length===0)empty('Пока нет рекомендаций','Найди книгу по названию или автору.',null,results);
      else results.append(el('div','loading'));
    }else if(isLibrary&&libraryExpanded&&!loadingLibrary)empty(libraryQuery?'Ничего не найдено':'В этом разделе пока нет книг',libraryQuery?'Попробуй другое название или имя автора.':'Выбери другой фильтр.',null,results);
    else{
      results.append(el('div','loading'));
      if(!isLibrary)errorTimer=setTimeout(()=>{if(!collectCards().length&&results.isConnected){results.replaceChildren();empty('Ничего не найдено','Попробуй другое название или имя автора.',null,results);}},6000);
    }
    if(isLibrary&&state.library){
      if(libraryError){showError(libraryError,results);results.append(button('Повторить',()=>{const entry=libraryEntry();entry.complete=false;entry.error='';expandLibrary(true);},'secondary'));}
      else if(loadingLibrary)results.append(el('p','sub','Загружаем все книги…'));
      else if(!libraryExpanded)setTimeout(()=>expandLibrary(true),0);
    }
    if(recommending&&!loadingRecommendations&&recommendations===null&&!recommendationError)setTimeout(loadRecommendations,0);
    if(searchInput&&searchInput.value!==libraryQuery&&isLibrary)searchInput.value=libraryQuery;
    panel.scrollTop=homeRestoreScroll??scroll;
    if(homeRestoreScroll!==null&&(Math.abs(panel.scrollTop-homeRestoreScroll)<2||libraryExpanded))homeRestoreScroll=null;
  }

  function renderAudio() {
    if(window.__booksNativeAudio){shell(false);return;}
    shell();document.documentElement.classList.remove('my-books-reader');
    const m=currentMedia(); const range=$('input[aria-label="Позиция воспроизведения"]');
    const duration=Number(range?.max)||m?.duration||0, position=Number(range?.value)||m?.currentTime||0;
    const playing=!!$('[data-test-id="AUDIO_PLAYER_PAUSE"]');
    const chapter=text('[data-test-id="AUDIO_PLAYER_CHAPTER"]');
    const title=meta?.title||text('[data-test-id="CONTENT_TITLE_MAIN"]')||'Аудиокнига';
    const cover=meta?.cover||coverURL($('[class*="ContentLeftColumn"] img')?.src||'');
    const author=meta?.author||text('[data-test-id="CONTENT_TITLE_AUTHOR"]');
    const signature=JSON.stringify([title,cover,author,chapter,playing,compact,settingsOpen,!!range]);
    if(signature!==lastSignature){
      lastSignature=signature;panel.querySelector('.search')?.remove();content.replaceChildren();
      panel.classList.toggle('compact',compact);const view=el('div','audio-view');const ambient=el('div','ambient');if(cover)ambient.style.backgroundImage='url('+JSON.stringify(cover)+')';view.append(ambient);const body=el('div','audio-content');view.append(body);
      const image=el('img','hero-cover');if(cover)image.src=cover;image.alt=title;body.append(image,el('h1','audio-title',title),el('div','audio-author',author));
      const info=el('div','audio-meta');info.append(el('span','chapter',chapter||normal(document.body.innerText).match(/Прослушано \d+%/)?.[0]||'Продолжить прослушивание'));
      const tools=el('div','tools');
      tools.append(button('Скорость',()=>window.webkit?.messageHandlers?.books?.postMessage({action:"settings"}),'tool', ''));
      tools.lastChild.textContent=(currentMedia()?.playbackRate || Number(localStorage.getItem('my-books-rate')) || 1)+'×';
      const chapterButton=button('Оглавление',openContents,'tool');chapterButton.textContent='';const glyph=el('span');glyph.style.cssText='display:block;width:18px;height:18px;background:currentColor;-webkit-mask:url('+window.__booksQueueIcon+') center/contain no-repeat;mask:url('+window.__booksQueueIcon+') center/contain no-repeat';chapterButton.append(glyph);tools.append(chapterButton);info.append(tools);body.append(info);
      const slider=el('input','timeline');slider.type='range';slider.min=0;slider.max=duration||1;slider.step=1;slider.value=position;slider.disabled=!duration;slider.setAttribute('aria-label','Позиция в главе');slider.addEventListener('change',()=>seek(Number(slider.value)));body.append(slider);
      const times=el('div','times');times.append(el('span','elapsed',time(position)),el('span','remaining',duration?'−'+time(duration-position):'—'));body.append(times);
      const controls=el('div','controls');
      const back=button('Назад на 30 секунд',()=>{playerButton('PREV')?.click();schedule();},'skip',icon('back30'));back.append(el('small','','30'));back.disabled=!range;
      const play=button(playing?'Пауза':'Слушать',togglePlayback,'play',playing?'<svg viewBox="0 0 24 24"><path d="M7 5h3v14H7zm7 0h3v14h-3z"/></svg>':icon('play')||'<svg viewBox="0 0 24 24"><path d="M7 4v16l14-8z"/></svg>');
      const forward=button('Вперёд на 30 секунд',()=>{playerButton('NEXT')?.click();schedule();},'skip',icon('forward30'));forward.append(el('small','','30'));forward.disabled=!range;
      controls.append(back,play,forward);body.append(controls,el('p','audio-note','Позиция сохраняется в Яндекс Книгах'));content.append(view);
    }
    const slider=$('.timeline',shadow);if(slider&&shadow.activeElement!==slider){slider.max=duration||1;slider.value=position;slider.disabled=!duration;}
    const elapsed=$('.elapsed',shadow),remaining=$('.remaining',shadow);if(elapsed)elapsed.textContent=time(position);if(remaining)remaining.textContent=duration?'−'+time(duration-position):'—';
  }
  function closeContents(){
    chaptersOpen=false;settingsOpen=false;
    document.documentElement.classList.remove('my-books-chapters');
    const b=playerButton('CONTENT');if(b?.getAttribute('aria-expanded')==='true')b.click();
    lastSignature='';renderAudio();
  }
  function renderContents(){
    const tracks=$$('[data-test-id="AUDIO_PLAYER_TRACK"]');
    const signature='chapters:'+tracks.map(t=>t.textContent+t.getAttribute('aria-current')).join('|');
    if(signature===lastSignature)return;lastSignature=signature;
    content.replaceChildren();const header=el('div','chapter-header');header.append(button('‹ К плееру',closeContents,'secondary'),el('h1','heading','Оглавление'));content.append(header);
    if(!tracks.length){content.append(el('div','loading'));return;}
    const list=el('div','list');for(const track of tracks){
      const name=text('[data-test-id="AUDIO_PLAYER_TRACK_INFO_TEXT"]',track);
      const duration=text('[data-test-id="AUDIO_PLAYER_TRACK_INFO_DURATION"]',track);
      const row=button(name,()=>{playbackAllowed=true;track.click();closeContents();},'chapter-row');
      row.textContent='';row.append(el('span','',name),el('span','sub',duration));
      if(track.getAttribute('aria-current')==='true')row.classList.add('active');list.append(row);
    }content.append(list);
    list.querySelector('.active')?.scrollIntoView({block:'center'});
  }
  function openContents(){window.webkit?.messageHandlers?.books?.postMessage({action:'chapters'});}
  function renderAudioSettings(){
    settingsOpen=true;shell();content.replaceChildren();const box=el('div','settings');box.append(button('‹ Назад',()=>{settingsOpen=false;lastSignature='';renderAudio();},'secondary'),el('h2','','Настройки аудио'));
    const speed=el('select');speed.setAttribute('aria-label','Скорость воспроизведения');for(const rate of [.75,1,1.25,1.5,1.75,2]){const o=el('option','',rate+'×');o.value=rate;speed.append(o);}speed.value=String(currentMedia()?.playbackRate||1);
    speed.addEventListener('change',()=>{for(const m of media)m.playbackRate=Number(speed.value);localStorage.setItem('my-books-rate',speed.value);});
    const sr=el('label','settings-row','Скорость');sr.append(speed);box.append(sr);
    const volume=el('input');volume.type='range';volume.min=0;volume.max=1;volume.step=.01;volume.value=currentMedia()?.volume??.8;volume.setAttribute('aria-label','Громкость');volume.addEventListener('input',()=>{for(const m of media)m.volume=Number(volume.value);});const vr=el('label','settings-row','Громкость');vr.append(volume);box.append(vr);
    const sleep=el('select');sleep.setAttribute('aria-label','Таймер сна');for(const [v,t]of [[0,'Выключен'],[15,'15 минут'],[30,'30 минут'],[60,'1 час']]){const o=el('option','',t);o.value=v;sleep.append(o);}sleep.addEventListener('change',()=>{clearTimeout(window.__booksSleep);if(Number(sleep.value))window.__booksSleep=setTimeout(pause,Number(sleep.value)*60000);});const tr=el('label','settings-row','Таймер сна');tr.append(sleep);box.append(tr,el('p','sub','Позиция и переходы между главами сохраняются Яндексом.'));content.append(box);
  }
  function settings(){
    if(state.mode==='reader'){originalClick('[data-test-id="FOOTER_SETTINGS"]')||originalClick('[data-test-id="HEADER_FONT"]');return;}
    if(state.mode==='audio'){if(chaptersOpen){closeContents();return;}if(settingsOpen){settingsOpen=false;lastSignature='';renderAudio();}else renderAudioSettings();return;}
    settingsOpen=!settingsOpen;if(!settingsOpen){lastSignature='';renderHome();return;}shell();content.replaceChildren();panel.querySelector('.search')?.remove();
    const box=el('div','settings');box.append(button('‹ Назад',settings,'secondary'),el('h2','','Мои книги'),el('p','sub','Компактный виджет для Яндекс Книг'),button('Открыть Яндекс Книги',()=>window.open('https://books.yandex.ru/','_blank'),'secondary'),button('Аккаунт Яндекса',login,'secondary'),el('div','footer','Версия 0.3.1'));content.append(box);
  }
  function home(){
    pause();playbackAllowed=false;settingsOpen=false;chaptersOpen=false;homeTab=0;
    navigate('/search');
  }
  function tab(index){
    settingsOpen=false;chaptersOpen=false;
    if(['reader','audio','detail'].includes(state.mode)){
      if(index===0&&state.hasText)navigate(meta?.reader||location.href);
      if(index===1&&state.hasAudio)navigate(meta?.audio||location.href);
      return;
    }
    if(index===homeTab)return;
    homeTab=index;filter='all';lastSignature='';
    if(index===0)navigate('/search');
    else if(state.library)navigate(state.library);
    else {localHome=true;state.selected=1;renderHome();post();}
  }
  async function updateRoute(){
    const path=location.pathname;
    const match=path.match(/^\/(reader|books|audiobooks)\/([^/]+)$/);
    const generation=++routeGeneration;
    meta=null;state.title='';state.author='';state.bookURL='';settingsOpen=false;chaptersOpen=false;libraryExpanded=false;libraryData=null;libraryError='';lastSignature='';panel?.classList.remove('compact');
    document.documentElement.classList.toggle('my-books-reader',match?.[1]==='reader');
    if(match){
      state.mode=match[1]==='reader'?'reader':match[1]==='audiobooks'?'audio':'detail';
      state.hasText=match[1]!=='audiobooks';state.hasAudio=match[1]==='audiobooks';state.selected=state.mode==='audio'?1:0;
      if(state.mode!=='detail')state.last=location.href;
      if(state.mode==='reader'){shell(false);updateReaderCover();}else if(state.mode==='audio')renderAudio();
      else {shell();content.replaceChildren(el('div','loading'));}
      post();
      try {
        meta=await metadata(match[1]==='audiobooks'?'audiobooks':'books',match[2]);
        if(generation!==routeGeneration)return;
        state.hasText=!!meta.reader;state.hasAudio=!!meta.audio;state.readerURL=meta.reader;
        state.title=meta.title;state.author=meta.author;
        state.bookURL=meta.reader?meta.reader.replace('/reader/','/books/').split('?')[0]:meta.audio;
        post();
        if(state.mode==='detail'&&meta.reader){navigate(meta.reader);return;}
        if(state.mode==='audio'){lastSignature='';renderAudio();}
        post();
      }catch{if(state.mode==='detail')showError('Книга недоступна. Попробуй открыть другую.');}
    }else{
      state.mode='home';state.hasText=false;state.hasAudio=false;
      homeTab=/^\/@/.test(path)?1:0;state.selected=homeTab;localHome=false;
      if(homeTab){libraryFilter=path.split('/').pop()||'all';filter=path.includes('/audiobooks/')?'audio':'text';}renderHome();post();
    }
  }
  function refresh(){
    if(!document.body)return;installPageStyle();mount();findLibrary();if(chaptersOpen){renderContents();post();return;}
    if(location.pathname!==lastRoute){lastRoute=location.pathname;updateRoute();return;}
    if(state.mode==='reader')updateReaderCover();
    if(state.mode==='home'&&!settingsOpen)renderHome();
    if(state.mode==='audio'&&!settingsOpen&& !$('#my-books-return'))renderAudio();
    post();
  }
  function schedule(){clearTimeout(timer);timer=setTimeout(refresh,80);}
  window.__books={home,tab,settings,
    homeViewState(){return {query:libraryQuery,scroll:panel?.scrollTop||0,format:filter,status:libraryFilter};},
    async restoreHomeViewState(saved){
      if(['text','audio'].includes(saved.format))filter=saved.format;
      if(['all','recent','not_finished','finished'].includes(saved.status))libraryFilter=saved.status;
      libraryQuery=typeof saved.query==='string'?saved.query:'';sessionStorage.setItem('my-books-library-query',libraryQuery);
      homeRestoreScroll=Math.max(0,Number(saved.scroll)||0);lastSignature='';renderHome();
      if(homeTab===1&&state.library){await expandLibrary(true);const until=Date.now()+15000;while(loadingLibrary&&Date.now()<until)await new Promise(resolve=>setTimeout(resolve,80));}
      return !loadingLibrary&&!libraryError;
    },
    async preparePresentation(){
      refresh();
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      installPageStyle();shell();
      return host.isConnected&&document.documentElement.hasAttribute('data-my-books-shell')&&getComputedStyle(host).visibility==='visible';
    },
    contents:openContents,chapterList,chapterSelect,chapterClose,chapterPlayback,togglePlayback,
    readerSettings(){originalClick('[data-test-id="FOOTER_SETTINGS"]')||originalClick('[data-test-id="HEADER_FONT"]');},
    audioSnapshot(){const range=$('input[aria-label="Позиция воспроизведения"]'),m=currentMedia();return {title:meta?.title||text('[data-test-id="CONTENT_TITLE_MAIN"]')||'Аудиокнига',author:meta?.author||'',cover:meta?.cover||'',chapter:text('[data-test-id="AUDIO_PLAYER_CHAPTER"]'),ready:!!(playerButton('PLAY')||playerButton('PAUSE')||$$('button').find(b=>normal(b.textContent)==='Слушать')),playing:!!$('[data-test-id="AUDIO_PLAYER_PAUSE"]'),position:Number(range?.value)||m?.currentTime||0,duration:Number(range?.max)||m?.duration||0,rate:m?.playbackRate||Number(localStorage.getItem('my-books-rate'))||1};},
    audioSkip(direction){playerButton(direction)?.click();},audioSeek:seek,
    pausePlayback:pause,
    emitState(){lastPost='';post();},
    readerInfo(){
      updateReaderCover();
      const controller=$('r-root')?.readerController;
      const sizes=controller?.readerSettings?.settings?.mapSizeConfigs;
      const nativeInsets=sizes&&typeof controller.readerApi?.runRepaint==='function';
      if(nativeInsets&&Object.values(sizes).some(size=>size.bottom!==12)){
        const mapSizeConfigs=Object.fromEntries(Object.entries(sizes).map(([key,size])=>[key,{...size,bottom:12}]));
        controller.readerApi.runRepaint({mapSizeConfigs});
      }
      const page=$('.embed-element');
      return {chapter:text('[class*="Footer-module"][class*="footer__left"]'),progress:text('[data-e2e="footer.progress"]'),dark:document.documentElement.style.colorScheme==='dark',bottomInset:nativeInsets?12:page?parseFloat(getComputedStyle(page).bottom)||12:null};
    },
    async readerQuick(action){
      const root=document.documentElement;const dark=root.style.colorScheme==='dark';root.classList.add('my-books-quick-settings');
      try{if(!$('[data-test-id="READER_SETTINGS_FONT_INCREASE"]'))(await waitFor('[data-test-id="FOOTER_SETTINGS"],[data-test-id="HEADER_FONT"]')).click();
        await waitFor('[data-test-id="READER_SETTINGS_FONT_INCREASE"]');
        const id=action==='increase'?'READER_SETTINGS_FONT_INCREASE':action==='decrease'?'READER_SETTINGS_FONT_DECREASE':dark?'READER_SETTINGS_THEME_LIGHT':'READER_SETTINGS_THEME_DARK';
        $('[data-test-id="'+id+'"]')?.click();
        const close=$('[data-test-id="READER_MODAL_CLOSE"]');
        if(close)close.click();
        else ($('[role="dialog"]')||document).dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,bubbles:true,composed:true}));
        const until=Date.now()+800;
        while($('[role="dialog"]')&&Date.now()<until)await new Promise(resolve=>setTimeout(resolve,40));
        return true;
      }finally{root.classList.remove('my-books-quick-settings');}
    },
    readerProgress(){return text('[data-e2e="footer.progress"]');},
    turnPage(direction){prepareReaderTurn(direction);$('[data-reader-page-direction="'+direction+'"]')?.click();},
    audioState(){return {rate:currentMedia()?.playbackRate||Number(localStorage.getItem('my-books-rate'))||1,volume:currentMedia()?.volume??.8};},
    audioSetting(name,value){if(name==='rate'){localStorage.setItem('my-books-rate',String(value));for(const m of media)m.playbackRate=Number(value);}if(name==='volume')for(const m of media)m.volume=Number(value);if(name==='sleep'){clearTimeout(window.__booksSleep);if(Number(value))window.__booksSleep=setTimeout(pause,Number(value)*60000);}},configure(options){if(options.library&&!state.library)state.library=safeURL(options.library);schedule();},compact(value){compact=value;lastSignature='';if(state.mode==='audio')renderAudio();},diagnostics(){return{...state,title:meta?.title||'',cards:collectCards().length,libraryComplete:libraryExpanded&&!libraryError,libraryRequests,libraryCacheReady:libraryCache.size===8&&[...libraryCache.values()].every(e=>e.complete&&!e.error),libraryLoading:loadingLibrary,libraryFormat:filter,libraryState:libraryFilter,recommendationCount:recommendations?.length||0,recommendationLoading:loadingRecommendations,recommendationError,media:media.size,shell:host?.style.display,overflow:panel?panel.scrollWidth>panel.clientWidth:false};}};
  document.addEventListener('play',e=>{if(e.target instanceof HTMLMediaElement)media.add(e.target);},true);
  let openingServiceContents=false, nativeChapterGeneration=0, nativeChapterData=null;
  const waitFor = async selector => {
    const until=Date.now()+8000;
    while(Date.now()<until){const node=$(selector);if(node)return node;await new Promise(resolve=>setTimeout(resolve,80));}
    throw new Error('Оглавление не загрузилось');
  };
  function chapterPlayback(){return {title:meta?.title||'',chapter:text('[data-test-id="AUDIO_PLAYER_CHAPTER"]'),playing:!!$('[data-test-id="AUDIO_PLAYER_PAUSE"]')};}
  async function chapterList(){
    const generation=++nativeChapterGeneration;
    const reading=state.mode==='reader';
    let tracks=[];
    if(reading){
      if(!$('[data-test-id="READER_MODAL_TOC_ITEM_TITLE"]')){
        const opener=await waitFor('[data-test-id="FOOTER_CONTENT"],[data-test-id="HEADER_CONTENT"]');
        if(generation!==nativeChapterGeneration)return {};
        openingServiceContents=true;opener.click();openingServiceContents=false;
      }
      await waitFor('[data-test-id="READER_MODAL_TOC_ITEM_TITLE"]');
      tracks=$$('[data-test-id="READER_MODAL_TOC_ITEM_TITLE"]').map((node,index)=>({id:String(index),index,title:normal(node.textContent),artist:'',current:node.closest('[data-test-id="READER_MODAL_TOC_ITEM"]')?.dataset.active==='true',duration:0}));
    }else{
      const id=location.pathname.split('/')[2];
      const data=await (await fetch('/node-api/p/api/v5/audiobooks/'+encodeURIComponent(id)+'/playlists.json',{credentials:'same-origin'})).json();
      const current=text('[data-test-id="AUDIO_PLAYER_CHAPTER"]');
      tracks=(data.tracks||[]).map((track,index)=>({id:track.uuid||String(index),index,title:'Глава '+(track.number??index+1),artist:'',duration:Number(track.duration?.seconds)||0,current:current==='Глава '+(track.number??index+1)}));
    }
    if(generation!==nativeChapterGeneration)return {};
    const playback=chapterPlayback();
    nativeChapterData={tracks,source:'book',reading,playing:playback.playing,current:{title:meta?.title||text('[data-test-id="READER_MODAL_TITLE"]'),artist:playback.chapter},notice:'В этой книге нет оглавления'};
    return nativeChapterData;
  }
  async function chapterSelect(index){
    if(!Number.isInteger(index)||index<0)return false;
    if(state.mode==='reader'){
      prepareReaderTurn();
      const node=$$('[data-test-id="READER_MODAL_TOC_ITEM_TITLE"]')[index];if(!node)return false;node.click();return true;
    }
    if(!playerButton('CONTENT')){
      playbackAllowed=true;const listen=$$('button').find(b=>normal(b.textContent)==='Слушать');if(!listen)return false;listen.click();await waitFor('[data-test-id="AUDIO_PLAYER_CONTENT"]');
    }
    if(!$('[data-test-id="AUDIO_PLAYER_TRACK"]'))playerButton('CONTENT')?.click();
    await waitFor('[data-test-id="AUDIO_PLAYER_TRACK"]');
    const node=$$('[data-test-id="AUDIO_PLAYER_TRACK"]')[index];if(!node)return false;playbackAllowed=true;node.click();return true;
  }
  function chapterClose(){
    ++nativeChapterGeneration;
    $('[data-test-id="READER_MODAL_CLOSE"]')?.click();
    const opener=playerButton('CONTENT');if(opener?.getAttribute('aria-expanded')==='true')opener.click();
  }
  const start=()=>{
    refresh();
    const observer=new MutationObserver(records=>{if(records.some(r=>!host?.contains(r.target)&&r.target!==host&&r.target?.id!=='my-books-style'))schedule();});
    observer.observe(document.body,{subtree:true,childList:true,characterData:true});
    setInterval(()=>{if(state.mode==='audio'&&!settingsOpen&&!$('#my-books-return'))renderAudio();},750);
    for(const method of ['pushState','replaceState']){const original=history[method];history[method]=function(...args){const result=original.apply(this,args);schedule();return result;};}
    addEventListener('popstate',schedule);addEventListener('pageshow',()=>{lastPost='';schedule();});
    document.addEventListener('keydown',e=>{if(state.mode==='reader'&&['ArrowLeft','ArrowRight','PageUp','PageDown'].includes(e.key))prepareReaderTurn(['ArrowLeft','PageUp'].includes(e.key)?'back':'forward');},true);
    document.addEventListener('click',e=>{const b=e.target.closest?.('[data-test-id="FOOTER_CONTENT"],[data-test-id="HEADER_CONTENT"]');if(b&&!openingServiceContents){e.preventDefault();e.stopImmediatePropagation();openContents();}},true);
    document.addEventListener('click',e=>{const a=e.target.closest?.('a[target="_blank"][href*="books.yandex.ru"],a[target="_blank"][href^="/reader/"]');if(a){e.preventDefault();navigate(a.href);}},true);
  };
  // Prepare before the service paints; login and the full website use separate configurations.
  const boot=()=>{
    if(!document.documentElement)return false;
    installPageStyle();
    const custom=!/^\/reader\/[^/]+$/.test(location.pathname);
    document.documentElement.classList.toggle('my-books-shell',custom);
    document.documentElement.toggleAttribute('data-my-books-shell',custom);
    if(!document.body)return false;
    start();return true;
  };
  if(!boot()){
    const ready=new MutationObserver(()=>{if(boot())ready.disconnect();});
    ready.observe(document,{subtree:true,childList:true});
  }
})();
