#!/bin/zsh
set -eu
cd "$(dirname "$0")"
app_source="./Мои книги.app"
if [[ ! -d "$app_source" ]]; then app_source="./build/Мои книги.app"; fi
if [[ ! -d "$app_source" ]]; then print -u2 -- "Приложение не найдено рядом с установщиком."; exit 1; fi
if pgrep -x MyBooks >/dev/null; then
    osascript -e 'tell application id "ru.ninesquares.mybooks" to quit'
    for attempt in {1..50}; do
        if ! pgrep -x MyBooks >/dev/null; then break; fi
        sleep 0.1
    done
    if pgrep -x MyBooks >/dev/null; then print -u2 -- "Закройте Мои книги и запустите установщик ещё раз."; exit 1; fi
fi
install_stage="$(mktemp -d /Applications/.mybooks-update.XXXXXX)"
ditto "$app_source" "$install_stage/Мои книги.app"
previous_app="$HOME/.Trash/Мои книги — предыдущая версия-$RANDOM.app"
if [[ -d "/Applications/Мои книги.app" ]]; then mv "/Applications/Мои книги.app" "$previous_app"; fi
if ! mv "$install_stage/Мои книги.app" "/Applications/Мои книги.app"; then
    if [[ -d "$previous_app" ]]; then mv "$previous_app" "/Applications/Мои книги.app"; fi
    exit 1
fi
rmdir "$install_stage"
open "/Applications/Мои книги.app"
print -- "Мои книги установлены."
